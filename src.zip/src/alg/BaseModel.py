

class BaseModel:
    pass