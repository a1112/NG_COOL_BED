
class ConfigBase:
    pass